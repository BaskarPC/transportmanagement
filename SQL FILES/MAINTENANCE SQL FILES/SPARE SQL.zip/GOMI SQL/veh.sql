 create table vehicle(vehicleid number(4),vehicletype number(4),instname number(4));


 insert into vehicle values(2,5,5);



 insert into vehicle values(4,8,3);



insert into vehicle values(1,2,3);

 insert into vehicle values(3,7,4);

 insert into vehicle values(6,2,1);

 insert into vehicle values(5,3,2);

 insert into vehicle values(7,1,4);

 insert into vehicle values(8,6,1);

 insert into vehicle values(9,9,3);

 insert into vehicle values(10,5,2);



SQL> create table number_lookup(id number(4),CODETYPE varchar2(100),codedesc varchar2(100));

Table created.
 insert into number_lookup values(1,'vehiclenumber','TN33P3083');


 insert into number_lookup values(2,'vehiclenumber','TN34AB3339');


 insert into number_lookup values(3,'vehiclenumber','TN36-1111');


 insert into number_lookup values(4,'vehiclenumber','TN34C3355');


 insert into number_lookup values(5,'vehiclenumber','TN56 6313');


 insert into number_lookup values(6,'vehiclenumber','TN63Y4722');


 insert into number_lookup values(7,'vehiclenumber','TN56 5015');


 insert into number_lookup values(8,'vehiclenumber','TN56 6302');

insert into number_lookup values(9,'vehiclenumber','TN60F7245');

 insert into number_lookup values(10,'vehiclenumber','TN33AE4762');


