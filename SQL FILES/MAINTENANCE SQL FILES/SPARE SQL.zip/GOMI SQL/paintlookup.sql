//PAINT LOOKUP

create table paintlookup(id number(4),code varchar2(30),codetype varchar2(30));

//LOOKUP FOR THE COMPANY NAME IN PAINT 
create table paint_company_lookup(id number(4),code number(4),codetype varchar2(20),partnumber varchar2(20));

//TO INSERT VALUES IN PAINTLOOKUP

insert into paintlookup values(1,'paint','Asian');
insert into paintlookup values(2,'paint','Rubilux');
insert into paintlookup values(3,'paint','Mixed');

// TO INSERT VALUES IN COMPANY LOOKUP FOR PAINT

insert into paint_company_lookup values(1,1,'Green','PP1');
insert into paint_company_lookup values(2,2,'Red','PP2');
insert into paint_company_lookup values(3,1,'Red','PP3');
insert into paint_company_lookup values(4,1,'Yellow','PP4');
insert into paint_company_lookup values(5,2,'Blue','PP5');
insert into paint_company_lookup values(6,3,'Black','PP6');
insert into paint_company_lookup values(7,3,'Green','PP7');
insert into paint_company_lookup values(8,2,'Black','PP8');


// COMMON TRANSACTION FOR PAINT 

CREATE TABLE PAINT_COMMON_TRANSACTION(PARTNUMBER number(4),
                              ITEMNAME VARCHAR2(45),
	              COMPNAME number(4),
                              SUBTYPE number(4),
                              OLD_QTY NUMBER(5),
                              NEW_QTY NUMBER(5),
                             OLD_RATE NUMBER(8,2),
                             NEW_RATE NUMBER(8,2),
                             TOLD_QTY NUMBER(5),
                             TNEW_QTY NUMBER(5),REORDER_LVL NUMBER(5));




// VALUES FOR PAINT COMMON TRANSACTION

INSERT INTO PAINT_COMMON_TRANSACTION VALUES(1,'paint',1,1,10,5,78.5,100.5,10,5,5);


INSERT INTO PAINT_COMMON_TRANSACTION VALUES(2,'paint',2,2,5,7,88,96.5,5,7,5);

INSERT INTO PAINT_COMMON_TRANSACTION VALUES(3,'paint',3,3,7,9,68,76.5,7,9,5);

INSERT INTO PAINT_COMMON_TRANSACTION VALUES(4,'paint',4,4,7,9,77.65,66.5,7,9,5);



